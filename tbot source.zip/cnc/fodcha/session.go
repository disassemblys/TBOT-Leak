package main

import (
	"fmt"
	"net"
	"sync"
)

var (
	sessions     = make(map[int64]*session)
	sessionMutex sync.Mutex
)

type session struct {
	ID       int64
	Username string
	Conn     net.Conn
	Account  AccountInfo
	Floods   int

	Chat bool
}

func (s *session) Remove() {
	fmt.Println("[session - Remove]", "Session closed")
	sessionMutex.Lock()
	delete(sessions, s.ID)
	sessionMutex.Unlock()
}

func (s *session) FetchAttacks(username string) {
	totalAttacks, err := database.GetTotalAttacks(username)
	if err != nil {
		fmt.Println("[session - FetchAttacks]", err)
		return
	}

	s.Floods = totalAttacks
}

func (a *Admin) Print(data ...interface{}) {
	_, _ = a.conn.Write([]byte(fmt.Sprint(data...)))
}

func (a *Admin) Printf(format string, val ...any) {
	a.Print(fmt.Sprintf(format, val...))
}

func (a *Admin) Println(data ...interface{}) {
	a.Print(fmt.Sprint(data...) + "\r\n")
}

func (a *Admin) Clear() {
	a.Printf("\x1bc")
}

func (s *session) Print(data ...interface{}) {
	_, _ = s.Conn.Write([]byte(fmt.Sprint(data...)))
}

func (s *session) Printf(format string, val ...any) {
	s.Print(fmt.Sprintf(format, val...))
}

func (s *session) Println(data ...interface{}) {
	s.Print(fmt.Sprint(data...) + "\r\n")
}

func (s *session) Clear() {
	s.Printf("\x1bc")
}

func (a *Admin) Close() {
	err := a.conn.Close()
	if err != nil {
		return
	}
}
