### Tbot CNC ~ Information & Compiling

## Information:
 - My name is Kent, I will be referring to myself as "I" or "me" in this.
 - My current telegram is https://t.me/k983242
 - Dosbots' current telegram is https://t.me/dosbots
 - This CNC was based on a mirai edit by Dosbot & I rewrote basically every single function
 - It took me just under a day to finish this project
 - This CNC's intended use is for tbot (t.me/tbotnet)
 - I lost count of how many lines this contains, my guess is around 2-3K
 - If you bully my code you like oily black men (gay niggers fucking ur ass) :trol:
 - If you somehow got this without permission, Kindly delete it :3 (or ill haunt your entire family tree)
 - I completed this on 15 September 2023, at 1:23 AM (good night im tired as fuck)


## Compiling:
 1. Install the latest golang: `apt install snapd -y && snap install go --classic`
 2. Install screen: `apt install screen -y`
 3. Build the source code into a binary: `go build`
 4. Remove useless source files (optional): `rm -rf *.go`
 5. Set connections to unlimited: `ulimit -n 999999`
 6. Start up your cnc: `screen -S cnc ./cnc`

## TermFX:
 - `<<$username>>`: User's username, for identifying.
 - `<<$botcount>>`: Current bot count.
 - `<<$ongoing>>`: Current global ongoing attacks.
 - `<<$maxglobal>>`: Maximum global attack slots.
 - `<<$totalattacks>>`: User total attacks.
 - `<<$maxattacs>>`: Maximum attacks for user.
 - suggest variables if you would like, https://t.me/k983242
## Colors:
 - usage: \x1b[{CODE}m
# Color codes:
 - 91: Red
 - 92: Green
 - 93: Yellow
 - 94: Blue
 - 95: Pink/purple
 - 96: Cyan
 - 97: White
 - 90: Gray
# Other color stuff:
 - 40: Background Gray
 - 43: Background Yellow
 - etc. Just replace the '9' with '4' for background, and '3' for a darker color

## Custom colors:
 - Visit: https://ibb.co/C2XvW66
 - For FOREGROUND colors replace "{CODE}" below with a code from the image above.
    - `[38;5;{CODE}m`
 - For BACKGROUND colors replace "{CODE}" below with a code from the image above.
    - `[48;5;{CODE}m`

### Connection
 1. Open a terminal of your preference (This is mainly for PuTTY, KiTTY, Termius, but you can also use the telnet command in cmd, unix, or elsewhere)
 2. On the main page:
    1. Set the host field to your server IP.
    2. Set the port field to `38241`. (or any custom port in config)
    3. Set the connection type to `Telnet`.
    4. Click connect.
    5. Credentials are shown on first startup, and saved to assets/default.credentials
